Open Visual Studio
Open solution from file: RestaurantLayoutAdvisor.sln
Run Execute/Debug